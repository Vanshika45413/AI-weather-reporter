
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { WeatherData } from '../types';

// IMPORTANT: This uses process.env.API_KEY. 
// Ensure this environment variable is set in your execution environment.
// DO NOT hardcode the API key here in a real application.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not found. Gemini API calls will fail. Please set it for the application to work.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "YOUR_API_KEY_HERE_IF_NOT_SET_IN_ENV" }); // Fallback for local dev if env not set.

export const getWeatherReport = async (city: string, name: string): Promise<WeatherData> => {
  const model = 'gemini-2.5-flash-preview-04-17';
  
  const prompt = `
    You are an AI Weather Reporter. Provide a weather report for ${city}.
    The user's name is ${name}.
    Include the current temperature in Celsius, the weather condition (e.g., Sunny, Cloudy, Rainy), 
    and an Air Quality Index (AQI) value (a number between 0 and 500, where lower is better).
    Also, provide a short, friendly, and personalized AI commentary about the weather and air quality, 
    suitable for ${name}. If AQI is high, suggest precautions.

    Return the response as a JSON object with the following structure:
    {
      "temperatureCelsius": number,
      "condition": "string",
      "aqi": number,
      "aiCommentary": "string"
    }
    Ensure the JSON is valid.
  `;

  try {
    if (!API_KEY && !ai.apiKey) { // Check if API key is truly missing
      throw new Error("Gemini API Key is not configured. Cannot fetch weather report.");
    }
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: [{role: "user", parts: [{text: prompt}]}],
      config: {
        responseMimeType: "application/json",
        temperature: 0.7, // Moderately creative for commentary
      },
    });

    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    
    const parsedData = JSON.parse(jsonStr) as WeatherData;
    
    // Basic validation of parsed data
    if (typeof parsedData.temperatureCelsius !== 'number' ||
        typeof parsedData.condition !== 'string' ||
        typeof parsedData.aqi !== 'number' ||
        typeof parsedData.aiCommentary !== 'string') {
      throw new Error("Received malformed weather data from AI.");
    }
      
    return parsedData;

  } catch (error) {
    console.error("Error fetching weather report from Gemini API:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred while fetching the weather report.";
    // Fallback or more specific error handling
    if (errorMessage.includes("API Key not valid")) {
        throw new Error("Invalid Gemini API Key. Please check your configuration.");
    }
    if (errorMessage.includes("Quota exceeded")) {
        throw new Error("Gemini API quota exceeded. Please try again later.");
    }
    throw new Error(`Failed to get weather report: ${errorMessage}`);
  }
};
