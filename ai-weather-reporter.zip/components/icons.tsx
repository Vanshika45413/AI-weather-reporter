
import React from 'react';
import { WeatherConditionIcon } from '../types';

export const LoadingSpinner: React.FC<{className?: string}> = ({ className = "w-6 h-6" }) => (
  <svg className={`${className} animate-spin text-white`} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
  </svg>
);

export const UserIcon: React.FC<{className?: string}> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
  </svg>
);

export const EmailIcon: React.FC<{className?: string}> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
    <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
  </svg>
);

export const CityIcon: React.FC<{className?: string}> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
  </svg>
);

export const getWeatherIcon = (condition: string): WeatherConditionIcon => {
  const lowerCondition = condition.toLowerCase();
  if (lowerCondition.includes('sun') || lowerCondition.includes('clear')) return WeatherConditionIcon.Sunny;
  if (lowerCondition.includes('partly cloudy')) return WeatherConditionIcon.PartlyCloudy;
  if (lowerCondition.includes('cloud')) return WeatherConditionIcon.Cloudy;
  if (lowerCondition.includes('rain') || lowerCondition.includes('shower')) return WeatherConditionIcon.Rainy;
  if (lowerCondition.includes('snow')) return WeatherConditionIcon.Snowy;
  if (lowerCondition.includes('wind')) return WeatherConditionIcon.Windy;
  if (lowerCondition.includes('storm') || lowerCondition.includes('thunder')) return WeatherConditionIcon.Stormy;
  if (lowerCondition.includes('fog') || lowerCondition.includes('mist')) return WeatherConditionIcon.Foggy;
  return WeatherConditionIcon.Default;
};
