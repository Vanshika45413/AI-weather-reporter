
import React from 'react';
import { WeatherData } from '../types';
import { getWeatherIcon } from './icons';

interface WeatherDisplayProps {
  city: string;
  weatherData: WeatherData;
}

const WeatherDisplay: React.FC<WeatherDisplayProps> = ({ city, weatherData }) => {
  const { temperatureCelsius, condition, aqi, aiCommentary } = weatherData;
  const weatherIconClass = getWeatherIcon(condition);

  const getAqiColor = (value: number): string => {
    if (value <= 50) return 'bg-green-500';
    if (value <= 100) return 'bg-yellow-500';
    if (value <= 150) return 'bg-orange-500';
    if (value <= 200) return 'bg-red-500';
    if (value <= 300) return 'bg-purple-500';
    return 'bg-red-700';
  };

  return (
    <div className="mt-8 p-6 bg-white/20 backdrop-blur-md rounded-xl shadow-2xl text-white">
      <h2 className="text-3xl font-bold mb-6 text-center">
        Weather in <span className="text-yellow-300">{city}</span>
      </h2>
      
      <div className="grid md:grid-cols-3 gap-6 mb-6 text-center">
        <div className="p-4 bg-white/10 rounded-lg shadow-lg">
          <p className="text-lg font-semibold mb-1">Temperature</p>
          <p className="text-4xl font-bold">
            {temperatureCelsius.toFixed(1)}<span className="text-2xl">°C</span>
          </p>
        </div>
        <div className="p-4 bg-white/10 rounded-lg shadow-lg flex flex-col items-center justify-center">
          <p className="text-lg font-semibold mb-1">Condition</p>
          <i className={`${weatherIconClass} text-4xl mb-2`}></i>
          <p className="text-xl">{condition}</p>
        </div>
        <div className="p-4 bg-white/10 rounded-lg shadow-lg">
          <p className="text-lg font-semibold mb-1">AQI</p>
          <p className={`text-4xl font-bold px-3 py-1 inline-block rounded-md ${getAqiColor(aqi)}`}>
            {aqi}
          </p>
        </div>
      </div>

      <div className="mt-6 p-4 bg-white/10 rounded-lg shadow-lg">
        <h3 className="text-xl font-semibold mb-2 text-yellow-300">AI Commentary</h3>
        <p className="text-lg leading-relaxed">{aiCommentary}</p>
      </div>
    </div>
  );
};

export default WeatherDisplay;
