
import React from 'react';
import { StoredData } from '../types';

interface EmailPreviewProps {
  data: StoredData;
}

const EmailPreview: React.FC<EmailPreviewProps> = ({ data }) => {
  const { fullName, city, temperature, condition, aqi, aiCommentary } = data;

  return (
    <div className="mt-8 p-6 bg-gray-800 rounded-xl shadow-2xl text-gray-200">
      <h2 className="text-2xl font-bold mb-4 text-center text-sky-400">Simulated Confirmation Email</h2>
      <div className="p-4 border border-gray-700 rounded-lg bg-gray-900">
        <p className="mb-2"><span className="font-semibold text-gray-400">To:</span> {data.email}</p>
        <p className="mb-4"><span className="font-semibold text-gray-400">Subject:</span> Your Weather Report for {city}</p>
        
        <hr className="border-gray-700 my-3"/>

        <p className="mb-3">Hi {fullName},</p>
        <p className="mb-3">Thanks for submitting your details.</p>
        {temperature !== undefined && condition && aqi !== undefined ? (
          <>
            <p className="mb-1">Here's the current weather for <span className="font-semibold text-sky-300">{city}</span>:</p>
            <ul className="list-disc list-inside ml-4 mb-3 text-gray-300">
              <li>Temperature: <span className="font-semibold">{temperature}°C</span></li>
              <li>Condition: <span className="font-semibold">{condition}</span></li>
              <li>AQI: <span className="font-semibold">{aqi}</span></li>
            </ul>
            {aiCommentary && (
              <div className="mt-3 mb-3 p-3 bg-gray-700/50 rounded">
                <p className="font-semibold text-sky-400 text-sm">Personalised Note:</p>
                <p className="italic text-gray-300">{aiCommentary}</p>
              </div>
            )}
          </>
        ) : (
          <p className="mb-3 text-yellow-400">Weather data is currently unavailable.</p>
        )}
        <p className="mb-1">Stay safe and take care!</p>
        <br />
        <p>Thanks,</p>
        <p>The AI Weather Reporter Team</p>
      </div>
      <p className="text-xs text-gray-500 mt-4 text-center">
        This is a simulation. In a real system, this email would be sent to your inbox.
      </p>
    </div>
  );
};

export default EmailPreview;
