
import React, { useState, useCallback } from 'react';
import { FormData, WeatherData, StoredData } from './types';
import { getWeatherReport } from './services/geminiService';
import WeatherDisplay from './components/WeatherDisplay';
import EmailPreview from './components/EmailPreview';
import { LoadingSpinner, UserIcon, EmailIcon, CityIcon } from './components/icons';

const App: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    email: '',
    city: '',
  });
  const [emailError, setEmailError] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [apiError, setApiError] = useState<string>('');
  const [weatherReport, setWeatherReport] = useState<WeatherData | null>(null);
  const [submittedData, setSubmittedData] = useState<StoredData | null>(null);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (name === 'email') {
      setEmailError(''); // Clear email error on change
    }
    setApiError(''); // Clear API error on any input change
  }, []);

  const validateEmail = (email: string): boolean => {
    // Basic regex for email validation
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setApiError('');
    setWeatherReport(null);
    setSubmittedData(null);

    if (!validateEmail(formData.email)) {
      setEmailError('Please enter a valid email address.');
      return;
    }
    setEmailError('');

    if (!formData.city) {
      setApiError('Please enter a city.');
      return;
    }
     if (!formData.fullName) {
      setApiError('Please enter your full name.');
      return;
    }


    setIsLoading(true);
    try {
      const report = await getWeatherReport(formData.city, formData.fullName);
      setWeatherReport(report);
      
      const currentSubmittedData: StoredData = {
        ...formData,
        emailValid: true,
        temperature: report.temperatureCelsius,
        condition: report.condition,
        aqi: report.aqi,
        aiCommentary: report.aiCommentary,
        timestamp: new Date().toISOString(),
      };
      setSubmittedData(currentSubmittedData);

    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
      setApiError(`Failed to fetch weather: ${errorMessage}`);
      // Store data even if AI call fails, but without weather info
      const currentSubmittedData: StoredData = {
        ...formData,
        emailValid: true,
        timestamp: new Date().toISOString(),
      };
      setSubmittedData(currentSubmittedData); // Show submitted data and email preview even on error
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto max-w-2xl p-4 sm:p-8">
      <header className="text-center mb-10">
        <h1 className="text-5xl font-extrabold text-white drop-shadow-lg">
          <i className="fas fa-cloud-sun-rain mr-3 text-yellow-300"></i>AI Weather Reporter
        </h1>
        <p className="text-sky-200 mt-2 text-lg">Get your personalized weather update!</p>
      </header>

      <form 
        onSubmit={handleSubmit} 
        className="bg-white/20 backdrop-blur-md p-8 rounded-xl shadow-2xl space-y-6"
      >
        <div>
          <label htmlFor="fullName" className="block text-sm font-medium text-sky-100 mb-1">Full Name</label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <UserIcon className="text-gray-400" />
            </div>
            <input
              type="text"
              name="fullName"
              id="fullName"
              value={formData.fullName}
              onChange={handleInputChange}
              className="w-full pl-10 pr-3 py-2.5 border border-transparent rounded-lg bg-white/30 text-white placeholder-gray-300 focus:ring-2 focus:ring-yellow-400 focus:border-transparent focus:outline-none shadow-sm"
              placeholder="e.g., Ada Lovelace"
              required
            />
          </div>
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-sky-100 mb-1">Email Address</label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
               <EmailIcon className="text-gray-400" />
            </div>
            <input
              type="email"
              name="email"
              id="email"
              value={formData.email}
              onChange={handleInputChange}
              className={`w-full pl-10 pr-3 py-2.5 border rounded-lg bg-white/30 text-white placeholder-gray-300 focus:ring-2 focus:border-transparent focus:outline-none shadow-sm ${emailError ? 'border-red-500 focus:ring-red-400' : 'border-transparent focus:ring-yellow-400'}`}
              placeholder="you@example.com"
              required
            />
          </div>
          {emailError && <p className="mt-1 text-sm text-red-300 bg-red-800/50 px-2 py-1 rounded">{emailError}</p>}
        </div>

        <div>
          <label htmlFor="city" className="block text-sm font-medium text-sky-100 mb-1">City</label>
           <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
               <CityIcon className="text-gray-400" />
            </div>
            <input
              type="text"
              name="city"
              id="city"
              value={formData.city}
              onChange={handleInputChange}
              className="w-full pl-10 pr-3 py-2.5 border border-transparent rounded-lg bg-white/30 text-white placeholder-gray-300 focus:ring-2 focus:ring-yellow-400 focus:border-transparent focus:outline-none shadow-sm"
              placeholder="e.g., London"
              required
            />
          </div>
        </div>
        
        {apiError && !weatherReport && <p className="mt-2 text-sm text-red-300 bg-red-800/50 px-2 py-1 rounded">{apiError}</p>}

        <button
          type="submit"
          disabled={isLoading}
          className="w-full flex items-center justify-center bg-yellow-400 hover:bg-yellow-500 disabled:bg-gray-400 text-gray-800 font-semibold py-3 px-4 rounded-lg shadow-md transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-yellow-600 focus:ring-offset-2 focus:ring-offset-sky-700"
        >
          {isLoading ? (
            <>
              <LoadingSpinner className="w-5 h-5 mr-2 text-gray-700" />
              Fetching Weather...
            </>
          ) : (
            <>
             <i className="fas fa-paper-plane mr-2"></i> Get Weather Report
            </>
          )}
        </button>
        <p className="text-xs text-sky-200 text-center">
            Note: An API key for Gemini API must be configured in the environment for this to work.
        </p>
      </form>

      {apiError && weatherReport && <p className="mt-4 text-center text-red-300 bg-red-800/50 px-3 py-2 rounded-lg">{apiError} <br/> Displaying previously submitted data or simulated email preview.</p>}

      {weatherReport && (
        <WeatherDisplay city={formData.city} weatherData={weatherReport} />
      )}

      {submittedData && (
        <EmailPreview data={submittedData} />
      )}
      
      {submittedData && (
        <div className="mt-8 p-6 bg-gray-800/80 backdrop-blur-sm rounded-xl shadow-2xl text-gray-300">
            <h3 className="text-xl font-bold mb-3 text-center text-sky-400">Data for Storage (Simulation)</h3>
            <pre className="text-xs bg-gray-900 p-4 rounded-md overflow-x-auto">
                {JSON.stringify(submittedData, null, 2)}
            </pre>
            <p className="text-xs text-gray-500 mt-3 text-center">
                This data would typically be sent to a backend and stored in a database like Supabase.
            </p>
        </div>
      )}
    </div>
  );
};

export default App;
