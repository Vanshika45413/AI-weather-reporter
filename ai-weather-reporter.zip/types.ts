
export interface FormData {
  fullName: string;
  email: string;
  city: string;
}

export interface WeatherData {
  temperatureCelsius: number;
  condition: string;
  aqi: number;
  aiCommentary: string;
}

export interface StoredData extends FormData {
  emailValid: boolean;
  temperature?: number;
  condition?: string;
  aqi?: number;
  aiCommentary?: string;
  timestamp: string;
}

export enum WeatherConditionIcon {
  Sunny = 'fas fa-sun',
  PartlyCloudy = 'fas fa-cloud-sun',
  Cloudy = 'fas fa-cloud',
  Rainy = 'fas fa-cloud-showers-heavy',
  Snowy = 'fas fa-snowflake',
  Windy = 'fas fa-wind',
  Stormy = 'fas fa-bolt',
  Foggy = 'fas fa-smog',
  Default = 'fas fa-question-circle'
}
